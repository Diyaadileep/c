/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float height;
    printf("enter your height");
    scanf("%f",&height);
    
    if(height<150.0){
        printf("the person is short");
    }
    else if(height>150.0 && height<170.0){
        printf("the person is avarage");
    }
    else if(height<170.0){
        printf("the person is tall");
    }
    else{
        printf("the person is very tall");
    }

    return 0;
}