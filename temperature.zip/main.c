/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float w;
    printf("enter the temperature:");
    scanf("%f",&w);
    if(w<0){
        printf("freezing weather");
    }
    else if(w>0 && w<10){
        printf("very cold weather");
    }
    else if(w>10 && w<20){
        printf("cold weather");
    }
    else if(w>20 && w<30){
        printf("normal temp");
    }
    else if(w>30 && w<40){
        printf("its hot");
    }
    else{
        printf("its very hot");
    }

    return 0;
}
